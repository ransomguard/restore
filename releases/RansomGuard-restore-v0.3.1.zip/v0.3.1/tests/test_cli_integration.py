import contextlib
from datetime import datetime, timedelta, timezone
import io
import json
import os
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch

from ransomguard.cli import main
from ransomguard.outbox import Outbox
from ransomguard.protocol import MAGIC, VERSION, PROCESS_SIZE, FILE_SIZE, FILE_FLAG_HIGH_ENTROPY, FILE_FLAG_PREOP_OBSERVATION


def event_stream():
    process = bytearray(PROCESS_SIZE)
    struct.pack_into("<IIIIQQ", process, 0, MAGIC, VERSION, 1, PROCESS_SIZE, 133000000000000000, 1)
    struct.pack_into("<IIIIqIIII", process, 32, 4100, 10, 10, 0, 133000000000000001, 0, 0, 0, 0)
    data = [bytes(process)]
    for sequence in (2, 3):
        write = bytearray(FILE_SIZE)
        path = r"\Device\HarddiskVolume3\Lab\note.txt".encode("utf-16-le")
        struct.pack_into("<IIIIQQ", write, 0, MAGIC, VERSION, 4, FILE_SIZE, 133000000000000100, sequence)
        struct.pack_into("<IIIIII", write, 32, 4100, 1, len(path), 0,
                         FILE_FLAG_HIGH_ENTROPY | FILE_FLAG_PREOP_OBSERVATION, 0)
        write[56:56 + len(path)] = path
        data.append(bytes(write))
    return data


class FakeReader:
    def __init__(self):
        self.records = iter(event_stream())

    def read(self):
        return next(self.records)

    def status(self):
        return {"test_reader": True}

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


class FakeUiSink:
    def __init__(self):
        self.messages = []

    def send(self, message):
        self.messages.append(message)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


class DropCounterReader(FakeReader):
    def __init__(self):
        super().__init__()
        self.polls = 0

    def status(self):
        self.polls += 1
        return {"events_dropped": 0 if self.polls == 1 else 1}


class OwnStorageNoiseReader(FakeReader):
    """A benign kernel file event from the observer, between real events."""

    def __init__(self, db_path):
        records = event_stream()
        internal = bytearray(records[1])
        path = str(db_path).encode("utf-16-le")
        struct.pack_into("<I", internal, 32, os.getpid())
        struct.pack_into("<I", internal, 40, len(path))
        internal[56:56 + len(path)] = path
        last = bytearray(records[2])
        struct.pack_into("<Q", last, 24, 4)
        self.records = iter([records[0], bytes(internal), records[2], bytes(last)])


class CliIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        self.config = self.directory / "config.json"
        self.config.write_text(json.dumps({"schema_version": 1, "recovery": {
            "volume_root": "C:\\", "snapshot_policy": "hourly_only", "snapshot_interval_seconds": 3600,
            "snapshot_creation_triggers": ["hourly_schedule"],
        }, "network": {"scope": "host_outbound", "jev_url": "https://api.typesafe.ai",
                        "extra_https_targets": []},
            "decision": {"thresholds_are_demo_only": True,
                         "benign_threshold": 0.2, "malicious_threshold": 0.8}}))

    def tearDown(self):
        self.temp.cleanup()

    def run_main(self, args):
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            return main(args)

    def test_real_decode_observer_intake_outbox_path_produces_one_candidate_without_actions(self):
        db = self.directory / "events.sqlite3"
        with patch("ransomguard.windows_reader.WindowsDriverReader", FakeReader):
            self.assertEqual(self.run_main(["observe", "--db", str(db), "--limit", "3"]), 0)
        with Outbox(db) as outbox:
            events = outbox.pending()
        self.assertEqual(sum(x["event_type"] == "kernel_event" for x in events), 3)
        candidates = [x["data"] for x in events if x["event_type"] == "track_b_candidate"]
        self.assertEqual(len(candidates), 1)
        candidate = candidates[0]
        self.assertEqual(candidate["track"], "B")
        self.assertEqual(candidate["pid"], 4100)
        self.assertFalse(candidate["identity_authorization"])
        self.assertFalse(candidate["containment_confirmed"])
        self.assertFalse(candidate["jev_requested"])
        self.assertFalse(any(x["event_type"] in ("quarantine_applied", "process_exit_confirmed", "jev_requested") for x in events))

    def test_self_db_write_is_not_persisted_or_triaged_and_keeps_sequence_contiguous(self):
        db = self.directory / "own-db.sqlite3"
        with patch("ransomguard.windows_reader.WindowsDriverReader", side_effect=lambda: OwnStorageNoiseReader(db)):
            self.assertEqual(self.run_main(["observe", "--db", str(db), "--limit", "4"]), 0)
        with Outbox(db) as outbox:
            events = outbox.pending()
        self.assertEqual(sum(x["event_type"] == "kernel_event" for x in events), 3)
        self.assertEqual(sum(x["event_type"] == "track_b_candidate" for x in events), 1)
        self.assertFalse(any(x["event_type"] == "triage_reset" for x in events))
        stored_sequences = [x["data"]["sequence"] for x in events if x["event_type"] == "kernel_event"]
        self.assertEqual(stored_sequences, [1, 3, 4])
        report = next(x["data"] for x in events if x["event_type"] == "observer_stopped")
        self.assertEqual(report["events_read"], 4)
        self.assertEqual(report["events_recorded"], 3)
        self.assertEqual(report["observer_storage_events_skipped"], 1)

    def test_live_observer_opt_in_requires_explicit_vm_authorization(self):
        db = self.directory / "no-unsafe-live.sqlite3"
        result = self.run_main(["observe", "--config", str(self.config), "--db", str(db),
                                "--live-track-b", "--response-state-db", str(self.directory / "holds.sqlite3"),
                                "--response-path-prefix", r"\Device\HarddiskVolume3\Lab",
                                "--response-no-recovery-required", "--limit", "3"])
        self.assertEqual(result, 1)
        self.assertFalse(db.exists())

    def test_live_observer_forwards_only_approved_candidate_to_response_coordinator(self):
        import os
        from types import SimpleNamespace
        from unittest.mock import MagicMock

        db = self.directory / "live-mocked.sqlite3"
        response = MagicMock()
        response.respond.return_value = SimpleNamespace(incident_id="incidentB", state="REVIEW_REQUIRED",
                                                       reason="jev_ambiguous_demo_threshold")
        with patch.dict(os.environ, {"TYPESAFE_API_KEY": "unit-test-placeholder"}), \
             patch("ransomguard.windows_reader.WindowsDriverReader", FakeReader), \
             patch("ransomguard.live_response.LiveResponseCoordinator", return_value=response):
            self.assertEqual(self.run_main([
                "observe", "--config", str(self.config), "--db", str(db), "--limit", "3",
                "--live-track-b", "--response-state-db", str(self.directory / "holds.sqlite3"),
                "--response-path-prefix", r"\Device\HarddiskVolume3\Lab",
                "--response-no-recovery-required", "--authorize-live", "--confirm-isolated-vm",
            ]), 0)
        self.assertEqual(response.respond.call_count, 1)
        kwargs = response.respond.call_args.kwargs
        self.assertEqual(kwargs["track"], "B")
        self.assertEqual(kwargs["process"].pid, 4100)
        self.assertEqual(kwargs["process"].create_time, 133000000000000001)
        self.assertTrue(kwargs["explicit_authorization"])
        with Outbox(db) as outbox:
            events = outbox.pending()
        report = next(x["data"] for x in events if x["event_type"] == "observer_stopped")
        self.assertTrue(report["live_response_enabled"])
        self.assertEqual(report["live_response_results"], {"REVIEW_REQUIRED": 1})

    def test_observer_emits_ui_json_without_enabling_live_response(self):
        db = self.directory / "ui-events.sqlite3"
        ui = FakeUiSink()
        with patch("ransomguard.windows_reader.WindowsDriverReader", FakeReader), \
             patch("ransomguard.ui_pipe.WindowsUiPipe", return_value=ui):
            self.assertEqual(self.run_main(["observe", "--ui", "--db", str(db), "--limit", "3"]), 0)
        self.assertEqual([msg["type"] for msg in ui.messages],
                         ["PROCESS_CREATE", "FILE_WRITE", "FILE_WRITE"])
        self.assertEqual(ui.messages[0]["data"]["processId"], 4100)
        with Outbox(db) as outbox:
            events = outbox.pending()
        report = next(event["data"] for event in events if event["event_type"] == "observer_stopped")
        self.assertEqual(report["local_ui_diagnostics"]["sent"], 3)
        self.assertTrue(report["local_ui_no_ack"])
        self.assertEqual(sum(event["event_type"] == "track_b_candidate" for event in events), 1)
        self.assertFalse(any(event["event_type"] == "termination_requested" for event in events))

    def test_advanced_driver_drop_counter_revokes_process_identity(self):
        db = self.directory / "drop-events.sqlite3"
        with patch("ransomguard.windows_reader.WindowsDriverReader", DropCounterReader):
            self.assertEqual(self.run_main(["observe", "--db", str(db), "--status-every", "1",
                                            "--limit", "3"]), 0)
        with Outbox(db) as outbox:
            events = outbox.pending()
        self.assertEqual(sum(e["event_type"] == "driver_event_loss_observed" for e in events), 1)
        self.assertTrue(any(e["event_type"] == "triage_reset" and
                            e["data"]["reason"] == "driver_drop_counter_advanced" for e in events))
        self.assertEqual(sum(e["event_type"] == "track_b_candidate" for e in events), 0)
        self.assertEqual(sum(e["event_type"] == "track_b_deferred" for e in events), 1)

    def test_snapshot_ui_notice_requires_verified_creation_and_never_changes_snapshot_status(self):
        db = self.directory / "snapshot-ui.sqlite3"
        result = {"status": "created", "created": True, "reason": "vss_create_verified",
                  "volume_root": "C:\\", "snapshot": {"snapshot_id": "{sample-id}"}}
        ui = FakeUiSink()
        with patch("ransomguard.snapshots.HourlySnapshotCoordinator") as coordinator, \
             patch("ransomguard.ui_pipe.WindowsUiPipe", return_value=ui):
            coordinator.return_value.run.return_value = result
            self.assertEqual(self.run_main(["snapshot-run", "--config", str(self.config),
                                            "--state-db", str(self.directory / "snapshots-ui.sqlite3"),
                                            "--db", str(db), "--ui"]), 0)
        self.assertEqual(len(ui.messages), 1)
        self.assertEqual(ui.messages[0]["type"], "VSS_STATUS")
        self.assertEqual(ui.messages[0]["data"]["action"], "BACKUP_CREATED")
        with Outbox(db) as outbox:
            notices = [e["data"] for e in outbox.pending() if e["event_type"] == "local_ui_snapshot_notice"]
        self.assertEqual(notices[0]["result"], "sent")
        self.assertFalse(notices[0]["ui_acknowledged"])

    def test_snapshot_result_is_logged_with_honest_exit_status(self):
        for status, code in (("created", 0), ("skipped", 0), ("failed", 1), ("unknown", 2)):
            with self.subTest(status=status), patch("ransomguard.snapshots.HourlySnapshotCoordinator") as coordinator:
                coordinator.return_value.run.return_value = {"status": status, "created": status == "created"}
                db = self.directory / (status + ".sqlite3")
                result = self.run_main(["snapshot-run", "--config", str(self.config), "--state-db",
                                       str(self.directory / "state.sqlite3"), "--db", str(db)])
                self.assertEqual(result, code)
                coordinator.return_value.run.assert_called_once_with(volume_root="C:\\", trigger="hourly_schedule")
                with Outbox(db) as outbox:
                    self.assertEqual(outbox.pending()[-1]["event_type"], "snapshot_" + status)

    def test_nonhourly_configuration_never_invokes_provider(self):
        config = json.loads(self.config.read_text())
        config["recovery"]["snapshot_creation_triggers"].append("incident")
        self.config.write_text(json.dumps(config))
        with patch("ransomguard.snapshots.HourlySnapshotCoordinator") as coordinator:
            code = self.run_main(["snapshot-run", "--config", str(self.config), "--state-db",
                                  str(self.directory / "state.sqlite3"), "--db", str(self.directory / "events.sqlite3")])
            self.assertEqual(code, 1)
            coordinator.assert_not_called()

    def test_scheduler_jitter_rechecks_only_unattempted_cooldown_once(self):
        for seconds in (2, -2):
            with self.subTest(seconds=seconds), patch("ransomguard.snapshots.HourlySnapshotCoordinator") as coordinator, patch("time.sleep") as sleep:
                coordinator.return_value.run.side_effect = [
                    {"status": "skipped", "reason": "hourly_cooldown", "attempted": False,
                     "next_eligible_at": (datetime.now(timezone.utc) + timedelta(seconds=seconds)).isoformat()},
                    {"status": "created", "created": True},
                ]
                code = self.run_main(["snapshot-run", "--config", str(self.config), "--state-db",
                                      str(self.directory / "state.sqlite3"), "--db", str(self.directory / (str(seconds) + ".sqlite3"))])
                self.assertEqual(code, 0)
                self.assertEqual(coordinator.return_value.run.call_count, 2)
                self.assertEqual(sleep.call_count, 1)
                self.assertLessEqual(sleep.call_args.args[0], 60.0)

    def test_uncertain_snapshot_result_is_never_retried_even_with_due_time(self):
        with patch("ransomguard.snapshots.HourlySnapshotCoordinator") as coordinator, patch("time.sleep") as sleep:
            coordinator.return_value.run.return_value = {
                "status": "unknown", "reason": "provider_timeout", "attempted": True,
                "next_eligible_at": datetime.now(timezone.utc).isoformat(),
            }
            code = self.run_main(["snapshot-run", "--config", str(self.config), "--state-db",
                                  str(self.directory / "state.sqlite3"), "--db", str(self.directory / "unknown.sqlite3")])
            self.assertEqual(code, 2)
            coordinator.return_value.run.assert_called_once()
            sleep.assert_not_called()

    def test_blocked_unknown_previous_attempt_is_not_reported_as_healthy_tick(self):
        with patch("ransomguard.snapshots.HourlySnapshotCoordinator") as coordinator, patch("time.sleep") as sleep:
            coordinator.return_value.run.return_value = {
                "status": "skipped", "reason": "unresolved_previous_attempt", "attempted": False,
                "requires_reconciliation": True, "next_eligible_at": datetime.now(timezone.utc).isoformat(),
            }
            code = self.run_main(["snapshot-run", "--config", str(self.config), "--state-db",
                                  str(self.directory / "state.sqlite3"), "--db", str(self.directory / "blocked.sqlite3")])
            self.assertEqual(code, 2)
            coordinator.return_value.run.assert_called_once()
            sleep.assert_not_called()

    def test_task_definition_generation_does_not_touch_snapshot_provider(self):
        config = json.loads(self.config.read_text())
        output = self.directory / "task.xml"
        with patch("ransomguard.cli._load_config", return_value=config), patch("ransomguard.snapshots.HourlySnapshotCoordinator") as coordinator:
            code = self.run_main(["snapshot-task", "--config", r"C:\Lab\config.json", "--state-db",
                                  r"C:\Lab\snapshots.sqlite3", "--db", r"C:\Lab\events.sqlite3",
                                  "--python-executable", r"C:\Lab\venv\Scripts\python.exe",
                                  "--user-sid", "S-1-5-21-111-222-333-1001", "--output", str(output)])
            self.assertEqual(code, 0)
            self.assertTrue(output.is_file())
            coordinator.assert_not_called()


if __name__ == "__main__":
    unittest.main()
